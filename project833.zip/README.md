# Project 3: From Portland to Portland
### Overview  
* Intro  
* Figma  
* Images  
  
**Intro**    
  
This is a project that showcases the hometowns of some of Practicum's employees. We've made it so all the elements are displayed correctly on popular screen sizes. We recommend investing more time in completing this project, since it's more difficult than previous ones.  
  
**Figma**  
  
* [Link to the project on Figma](https://www.figma.com/file/AtbNbstbxWPcMqvF061V0R/Sprint-3-From-Portland-to-Portland-desktop-mobile)  
  
**Images**  
  
  descriptio:
  This project is a responsive website, it allows to view in small screens ipods and labtops.
  There been a use of the Grid property in this project.
  all the images have been shrinked with tinypng
  
The way you'll do this at work is by exporting images directly from Figma — we recommend doing that to practice more. Don't forget to optimize them [here](https://tinypng.com/), so your project loads faster. 
  
Good luck and have fun!  


This is the link to the site https://ohadgross.github.io/web_project_3/
